jest.mock('@/lib/env', () => ({ env: { NODE_ENV: 'test' } }));
jest.mock('@/lib/agent/redis-simple', () => ({ simpleRedisManager: { isRedisConnected: () => false } }));

import { httpGet, getHttpInflightStats } from '@/lib/http-client';
import { withExecutionSignal, withExecutionScope, getExecutionBudgetUsage } from '@/lib/worker/execution-scope';

const originalFetch = global.fetch;
const fetchMock = jest.fn();

beforeEach(() => {
  fetchMock.mockReset();
  global.fetch = fetchMock;
});
afterEach(() => { global.fetch = originalFetch; });

test('declared oversized bodies are cancelled without downloading them', async () => {
  const cancel = jest.fn();
  fetchMock.mockResolvedValue(new Response(new ReadableStream({ cancel }), {
    headers: { 'content-length': String(100 * 1024 * 1024) },
  }));
  await expect(httpGet('https://example.test/large', { retries: 0 })).rejects.toThrow(/limit|large|size/i);
  expect(cancel).toHaveBeenCalledTimes(1);
  expect(fetchMock).toHaveBeenCalledTimes(1);
});

test('chunked oversized responses cannot bypass the byte limit or trigger retries', async () => {
  const cancel = jest.fn();
  fetchMock.mockImplementation(async () => {
    let chunks = 0;
    return new Response(new ReadableStream({
      pull(controller) {
        if (chunks++ < 12) controller.enqueue(new Uint8Array(1024 * 1024));
        else controller.close();
      },
      cancel,
    }));
  });
  await expect(httpGet('https://example.test/chunked', { retries: 3, retryDelay: 1 })).rejects.toThrow(/limit|large|size/i);
  expect(cancel).toHaveBeenCalledTimes(1);
  expect(fetchMock).toHaveBeenCalledTimes(1);
});

test('timeout includes the body, not only response headers', async () => {
  const cancel = jest.fn();
  fetchMock.mockResolvedValue(new Response(new ReadableStream({ cancel })));
  await expect(httpGet('https://example.test/stalled', { timeout: 30, retries: 0 })).rejects.toThrow();
  expect(cancel).toHaveBeenCalledTimes(1);
  expect(getHttpInflightStats().active).toBe(0);
});

test('parent cancellation aborts the body and suppresses all HTTP retries', async () => {
  const controller = new AbortController();
  const cancel = jest.fn();
  let started!: () => void;
  const ready = new Promise<void>(resolve => { started = resolve; });
  fetchMock.mockImplementation(async () => {
    started();
    return new Response(new ReadableStream({ cancel }));
  });
  const work = withExecutionSignal(controller.signal, () => httpGet('https://example.test/cancel', { retries: 3 }));
  const failed = expect(work).rejects.toThrow('lease lost');
  await ready;
  controller.abort(new Error('lease lost'));
  await failed;
  expect(fetchMock).toHaveBeenCalledTimes(1);
  expect(cancel).toHaveBeenCalledTimes(1);
  expect(getHttpInflightStats().active).toBe(0);
});

test('300 logical calls never exceed the shared in-flight limit', async () => {
  let active = 0;
  let peak = 0;
  fetchMock.mockImplementation(async () => {
    active++;
    peak = Math.max(peak, active);
    await new Promise(resolve => setTimeout(resolve, 1));
    active--;
    return new Response('{"ok":true}');
  });
  const results = await Promise.all(Array.from({ length: 300 }, () =>
    httpGet('https://example.test/small', { retries: 0 }),
  ));
  expect(results).toHaveLength(300);
  expect(peak).toBeLessThanOrEqual(getHttpInflightStats().cap);
  expect(getHttpInflightStats()).toMatchObject({ active: 0, pending: 0 });
});

test('per-upstream budget stops real requests once the cap is reached', async () => {
  fetchMock.mockImplementation(async () => new Response('{"ok":true}'));
  const controller = new AbortController();
  const results = await withExecutionSignal(controller.signal, () =>
    Promise.allSettled(Array.from({ length: 410 }, (_, i) =>
      httpGet(`https://api.test-upstream.test/x?p=${i}`, { retries: 0, rateLimiterKey: 'test-upstream' }),
    )),
  );
  const ok = results.filter(r => r.status === 'fulfilled');
  const blocked = results.filter(r =>
    r.status === 'rejected' && /budget exhausted/i.test(String(r.reason?.message)),
  );
  expect(ok).toHaveLength(400);
  expect(blocked).toHaveLength(10);
  expect(fetchMock).toHaveBeenCalledTimes(400);
});

test('a new execution scope gets a fresh upstream budget', async () => {
  fetchMock.mockImplementation(async () => new Response('{"ok":true}'));
  const first = new AbortController();
  await withExecutionSignal(first.signal, () =>
    Promise.allSettled(Array.from({ length: 405 }, (_, i) =>
      httpGet(`https://api.test-upstream.test/x?a=${i}`, { retries: 0, rateLimiterKey: 'test-upstream' }),
    )),
  );
  const second = new AbortController();
  const results = await withExecutionSignal(second.signal, () =>
    Promise.allSettled(Array.from({ length: 5 }, (_, i) =>
      httpGet(`https://api.test-upstream.test/x?b=${i}`, { retries: 0, rateLimiterKey: 'test-upstream' }),
    )),
  );
  expect(results.every(r => r.status === 'fulfilled')).toBe(true);
});

test('sibling scopes each get a fresh upstream cap but share the job-root bound', async () => {
  fetchMock.mockImplementation(async () => new Response('{"ok":true}'));
  const job = new AbortController();
  const perNode = await withExecutionSignal(job.signal, async () => {
    const tally: number[] = [];
    for (let n = 0; n < 6; n++) {
      const results = await withExecutionScope(`node-${n}`, () =>
        Promise.allSettled(Array.from({ length: 400 }, (_, i) =>
          httpGet(`https://api.test-upstream.test/y?n=${n}&i=${i}`, { retries: 0, rateLimiterKey: 'test-upstream' }),
        )),
      );
      tally.push(results.filter(r => r.status === 'fulfilled').length);
    }
    return tally;
  });
  // scope cap 400/node; root cap 4×400=1600 → nodes 0-3 pass fully, 4-5 denied
  expect(perNode).toEqual([400, 400, 400, 400, 0, 0]);
});

test('retries consume real budget — a 4-attempt call counts 4 wire requests', async () => {
  fetchMock.mockImplementation(async () => new Response('boom', { status: 500 }));
  const controller = new AbortController();
  const usage = await withExecutionSignal(controller.signal, async () => {
    await httpGet('https://api.test-upstream.test/x?r=1', {
      retries: 3, retryDelay: 1, rateLimiterKey: 'test-upstream',
    }).catch(() => {});
    return getExecutionBudgetUsage('http:test-upstream');
  });
  expect(usage).toBe(4);
  expect(fetchMock).toHaveBeenCalledTimes(4);
});

test('identical GETs within TTL share one wire request (run-scoped dedupe)', async () => {
  fetchMock.mockImplementation(async () => new Response('{"ok":true}'));
  const url = 'https://api.dedupe.test/search?q=artificial+intelligence';
  const [a, b, c] = await Promise.all([
    httpGet(url, { retries: 0 }),
    httpGet(url, { retries: 0 }),
    httpGet(url, { retries: 0 }),
  ]);
  expect(fetchMock).toHaveBeenCalledTimes(1);
  expect(a).toEqual({ ok: true });
  // sequential hit — still deduped
  await httpGet(url, { retries: 0 });
  expect(fetchMock).toHaveBeenCalledTimes(1);
  // mutations by one caller must not corrupt the shared payload
  (a as any).ok = false;
  const d = await httpGet(url, { retries: 0 });
  expect(d).toEqual({ ok: true });
  // cache:false bypasses
  await httpGet(url, { retries: 0, cache: false });
  expect(fetchMock).toHaveBeenCalledTimes(2);
});

test('oversized responses self-evict — a repeat call re-issues the wire request', async () => {
  const big = 'x'.repeat(1.5 * 1024 * 1024);
  fetchMock.mockImplementation(async () => new Response(`{"d":"${big}"}`));
  const url = 'https://api.dedupe.test/oversized';
  await httpGet(url, { retries: 0 });
  // Allow the async size-check eviction to run.
  await new Promise(r => setImmediate(r));
  await httpGet(url, { retries: 0 });
  expect(fetchMock).toHaveBeenCalledTimes(2);
});

test('failed GETs are not cached — a retry re-issues the wire request', async () => {
  let calls = 0;
  fetchMock.mockImplementation(async () => {
    calls++;
    return calls === 1 ? new Response('boom', { status: 500 }) : new Response('{"ok":1}');
  });
  const url = 'https://api.dedupe.test/flaky';
  await httpGet(url, { retries: 0 }).catch(() => {});
  const res = await httpGet(url, { retries: 0 });
  expect(calls).toBe(2);
  expect(res).toEqual({ ok: 1 });
});

test('scout budget lane caps discovery spend while preserving upstream budget for repair', async () => {
  process.env.HTTP_LANE_SCOUT_OPENALEX = '3';
  try {
    fetchMock.mockImplementation(async () =>
      new Response(JSON.stringify({ ok: true }), { status: 200, headers: { 'content-type': 'application/json' } }));
    await withExecutionScope('lane-test', async () => {
      const { withHttpBudgetLane } = await import('@/lib/http-client');
      const opt = { rateLimiterKey: 'openalex', retries: 0 } as const;
      // 3 scout-lane requests admitted.
      for (let i = 0; i < 3; i++) {
        await withHttpBudgetLane('scout', () => httpGet(`https://api.openalex.org/lane-ok-${i}`, opt));
      }
      // 4th inside the lane → lane exhausted even though upstream budget remains.
      await expect(
        withHttpBudgetLane('scout', () => httpGet('https://api.openalex.org/lane-full', opt))
      ).rejects.toThrow(/lane/i);
      // Outside the lane (gap-fill / repair retrieval) the same upstream still has budget.
      await httpGet('https://api.openalex.org/repair-ok', opt);
    });
    expect(fetchMock).toHaveBeenCalledTimes(4);
  } finally {
    delete process.env.HTTP_LANE_SCOUT_OPENALEX;
  }
});
