import { NextRequest, NextResponse } from "next/server";
import { runThinkTankCycle, getThinkTankStatus } from "@/lib/agent/think-tank-dispatcher";
import { enqueueThinkTankCycle } from "@/lib/worker/think-tank-queue";
import { verifyBearerToken } from "@/lib/security/timing-safe";

/**
 * POST /api/cron/auto-scan
 *
 * Think tank — breaking cycle (2×/day).
 * Default: enqueues a durable Job → 202 (worker executes the long pipeline).
 * Escape hatch: POST ?sync=1 runs inline (local/manual use only).
 */
export async function POST(req: NextRequest) {
  const startTime = Date.now();

  try {
    const authHeader = req.headers.get("authorization");

    if (!verifyBearerToken(authHeader, process.env.CRON_SECRET)) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const sync = req.nextUrl.searchParams.get("sync") === "1" || process.env.THINK_TANK_INLINE === "1";

    if (!sync) {
      const queued = await enqueueThinkTankCycle({ mode: "breaking" });
      console.log(`[AUTO-SCAN] enqueue → ${queued.jobId} (${queued.reason ?? "enqueued"})`);
      return NextResponse.json(
        {
          success: true,
          architecture: "think-tank-dispatcher:breaking:durable",
          queued: queued.enqueued,
          reason: queued.reason,
          jobId: queued.jobId,
          durationMs: Date.now() - startTime,
        },
        { status: 202 }
      );
    }

    console.log("[AUTO-SCAN] → ThinkTankDispatcher (breaking, sync)");

    const result = await runThinkTankCycle({ mode: "breaking" });

    return NextResponse.json({
      success: result.success,
      architecture: "think-tank-dispatcher:breaking",
      stats: {
        mode: result.mode,
        collected: result.collected,
        published: result.published,
        held: result.held,
        skipped: result.skipped,
        failed: result.failed,
        strategicPublished: result.published,
        briefsPublished: 0,
        totalCostUsd: result.totalCostUsd,
        errors: result.errors,
        phases: result.phases,
        cadence: result.cadence,
        topics: result.topics,
        editorial: result.outcomes.map((o) => ({
          topic: o.item.question.slice(0, 80),
          domain: o.item.domain,
          strategy: o.item.strategy,
          status: o.result.status,
          trustScore: o.result.trustScore,
        })),
        durationMs: Date.now() - startTime,
        durationMin: (Date.now() - startTime) / 60000,
        timestamp: new Date().toISOString(),
      },
    });
  } catch (error: unknown) {
    console.error("[AUTO-SCAN] Fatal error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  const authHeader = req.headers.get("authorization");

  if (!verifyBearerToken(authHeader, process.env.CRON_SECRET)) {
    return NextResponse.json({ error: "Unauthorized - Admin only" }, { status: 401 });
  }

  const status = await getThinkTankStatus();

  return NextResponse.json({
    message: "NomosX Think Tank — dispatcher",
    ...status,
  });
}
