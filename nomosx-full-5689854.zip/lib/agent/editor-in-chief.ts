/**
 * NomosX EDITOR-IN-CHIEF — LLM Triage for Breaking Topics
 * 
 * The "DECIDE" step in the DETECT → DECIDE → DELEGATE architecture.
 * Takes raw RadarTopic[] from TopicRadar and decides:
 * 
 *   1. Is this NEW? (not already covered in recent publications)
 *   2. Is this URGENT? (time-sensitive, breaking)
 *   3. Do we have an ANGLE? (can our researchers add value?)
 *   4. What FORMAT? (brief vs strategic)
 *   5. WHO handles it? (which researcher, which providers)
 * 
 * Single LLM call with gpt-4o-mini — fast, cheap (~$0.001), decisive.
 */

import { callLLM } from '../llm/unified-llm';
import { parseJson } from './json-utils';
import { prisma } from '../db';
import { classifyTopic, TopicClassification } from './topic-classifier';
import { agendaPriorityBoost, type ResearchAgendaContext } from './research-agenda';
import type { RadarTopic } from './topic-radar';

// ============================================================================
// TYPES
// ============================================================================

export interface EditorialDecision {
  /** The selected topic */
  topic: RadarTopic;
  /** What to do with it */
  action: 'publish_signal' | 'publish_memo' | 'publish_brief' | 'publish_strategic' | 'monitor' | 'skip';
  /** Why this decision */
  reasoning: string;
  /** Priority 0-100 */
  priority: number;
  /** Full topic classification (domain, researchers, providers) */
  classification: TopicClassification;
  /** Estimated pipeline cost */
  estimatedCostUsd: number;
  /** Analytical research question reformulated from the raw headline (think-tank framing) */
  researchQuestion?: string;
  /** How much the question challenges conventional thinking (0-100) */
  intellectualAmbition?: number;
  /** Strength of heterodox/contrarian angle (0-100) */
  contrarianSignal?: number;
}

export interface EditorialTriageResult {
  decisions: EditorialDecision[];
  skipped: number;
  costUsd: number;
  durationMs: number;
}

// ============================================================================
// MAIN ENTRY POINT
// ============================================================================

/**
 * Editor-in-Chief triage — takes radar topics, returns publication decisions.
 * Should complete in <15 seconds.
 * 
 * @param topics - Raw topics from TopicRadar
 * @param options - Budget and slot constraints
 */
export async function editorialTriage(
  topics: RadarTopic[],
  options?: {
    maxPublications?: number;
    budgetUsd?: number;
    /** Research agenda context — domain coverage deficits + flagship
     *  questions. Injected into the triage prompt and used for a
     *  deterministic under-covered-domain promotion below. */
    agenda?: ResearchAgendaContext;
  }
): Promise<EditorialTriageResult> {
  const start = Date.now();
  const maxPubs = options?.maxPublications ?? 3;
  const budgetUsd = options?.budgetUsd ?? 20.0;

  if (topics.length === 0) {
    return { decisions: [], skipped: 0, costUsd: 0, durationMs: 0 };
  }

  console.log(`[EDITOR-IN-CHIEF] Triaging ${topics.length} topics (max ${maxPubs} publications, budget $${budgetUsd})...`);

  // Step 1: Get recent publications to avoid duplicates
  const recentTitles = await getRecentPublicationTitles();

  // Step 2: LLM triage — single call to select + prioritize
  const triageResult = await llmTriage(topics, recentTitles, maxPubs, options?.agenda);

  // Step 2b: DETERMINISTIC DOMAIN DIVERSITY — ensure multi-domain coverage
  // The LLM may over-cluster on one domain. This filter guarantees variety.
  // Resolve topicId → topic robustly: the LLM may return the index, an
  // invented id, or a slightly mangled one. Silent lookup failures were
  // previously counted as "budget-cut" and dropped whole selections.
  const resolveTopic = (topicId: string): RadarTopic | undefined => {
    const direct = topics.find(t => t.id === topicId);
    if (direct) return direct;
    const asIndex = Number(topicId);
    if (Number.isInteger(asIndex) && topics[asIndex]) return topics[asIndex];
    const normalized = String(topicId).toLowerCase().replace(/[^a-z0-9]/g, '');
    return topics.find(t => t.id.toLowerCase().replace(/[^a-z0-9]/g, '') === normalized
      || t.title.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 60) === normalized.slice(0, 60));
  };

  const seenVerticals = new Set<string>();
  const diverseSelected: TriageSelection[] = [];
  const droppedForDiversity: TriageSelection[] = [];
  let unresolvedCount = 0;

  for (const selected of triageResult.selected) {
    const topic = resolveTopic(selected.topicId);
    if (!topic) { unresolvedCount++; continue; }
    const vertical = topic.vertical || 'unknown';

    if (maxPubs > 1 && seenVerticals.has(vertical)) {
      // Already have a topic from this vertical — skip for diversity
      droppedForDiversity.push(selected);
      continue;
    }
    seenVerticals.add(vertical);
    diverseSelected.push(selected);
  }

  // If diversity filter left slots empty, backfill from dropped items (best score first)
  if (diverseSelected.length < maxPubs && droppedForDiversity.length > 0) {
    droppedForDiversity.sort((a, b) => (b.priority ?? 0) - (a.priority ?? 0));
    for (const dropped of droppedForDiversity) {
      if (diverseSelected.length >= maxPubs) break;
      diverseSelected.push(dropped);
    }
  }

  if (droppedForDiversity.length > 0) {
    console.log(`[EDITOR-IN-CHIEF] Domain diversity filter: ${droppedForDiversity.length} topics dropped (same vertical), ${diverseSelected.length} kept across ${seenVerticals.size} verticals`);
  }

  if (unresolvedCount > 0) {
    console.warn(`[EDITOR-IN-CHIEF] ${unresolvedCount}/${triageResult.selected.length} selections had unresolvable topicIds — LLM returned ids not matching radar topics`);
  }

  // Step 3: For selected topics, run full classification to get researchers + providers
  const decisions: EditorialDecision[] = [];
  let totalCost = triageResult.costUsd;
  let remainingBudget = budgetUsd;

  for (const selected of diverseSelected) {
    const topic = resolveTopic(selected.topicId);
    if (!topic) continue;

    // Full classification
    const classification = await classifyTopic(topic.title, topic.summary);
    totalCost += classification.costUsd;

    const estimatedCost = selected.action === 'publish_strategic' ? 10.0
      : selected.action === 'publish_brief' ? 3.0
      : selected.action === 'publish_memo' ? 1.5
      : selected.action === 'publish_signal' ? 0.5
      : 2.0;

    if (estimatedCost > remainingBudget && selected.priority < 90) {
      continue; // Skip if over budget (unless critical)
    }

    decisions.push({
      topic,
      action: selected.action,
      reasoning: selected.reasoning,
      priority: selected.priority,
      classification,
      estimatedCostUsd: estimatedCost,
      researchQuestion: selected.researchQuestion,
      intellectualAmbition: selected.intellectualAmbition,
      contrarianSignal: selected.contrarianSignal,
    });

    remainingBudget -= estimatedCost;
  }

  // ── AGENDA REBALANCE — deterministic under-covered-domain promotion ──
  // The prompt nudge is advisory; this guarantees the desk's coverage
  // obligation survives an LLM that clustered anyway. Only fires when NO
  // selected decision already serves a deficit domain, and only swaps out
  // a decision whose priority is within 25 points of the candidate — a
  // clearly superior topic is never displaced for balance.
  const agenda = options?.agenda;
  if (agenda && agenda.deficitSlugs.length > 0 && decisions.length > 1) {
    const hasDeficitPick = decisions.some(d =>
      d.classification?.verticalSlug && agenda.deficitSlugs.includes(d.classification.verticalSlug));
    if (!hasDeficitPick) {
      const droppedSorted = [...droppedForDiversity]
        .filter(d => !diverseSelected.includes(d)) // backfilled picks are already selected
        .sort((a, b) => (b.priority ?? 0) - (a.priority ?? 0));
      for (const dropped of droppedSorted) {
        const topic = resolveTopic(dropped.topicId);
        if (!topic) continue;
        const cls = await classifyTopic(topic.title, topic.summary).catch(() => null);
        totalCost += cls?.costUsd ?? 0;
        const slug = cls?.verticalSlug;
        if (!slug || !agenda.deficitSlugs.includes(slug)) continue;
        const worstIdx = decisions.reduce(
          (mi, d, i) => (d.priority < decisions[mi].priority ? i : mi), 0);
        if ((decisions[worstIdx].priority ?? 0) - (dropped.priority ?? 0) > 25) {
          console.log(`[EDITOR-IN-CHIEF] Agenda rebalance: best deficit candidate "${topic.title.slice(0, 50)}" (${slug}) too far below worst pick — keeping quality order`);
          break;
        }
        const estCost = dropped.action === 'publish_strategic' ? 10.0
          : dropped.action === 'publish_brief' ? 3.0
          : dropped.action === 'publish_memo' ? 1.5
          : dropped.action === 'publish_signal' ? 0.5 : 2.0;
        decisions[worstIdx] = {
          topic,
          action: dropped.action,
          reasoning: `${dropped.reasoning || ''} [agenda: ${slug} under-covered]`.trim(),
          priority: Math.min(100, (dropped.priority ?? 50) + agendaPriorityBoost(slug, agenda)),
          classification: cls!,
          estimatedCostUsd: estCost,
          researchQuestion: dropped.researchQuestion,
          intellectualAmbition: dropped.intellectualAmbition,
          contrarianSignal: dropped.contrarianSignal,
        };
        console.log(`[EDITOR-IN-CHIEF] Agenda rebalance: promoted "${topic.title.slice(0, 50)}" (${slug}) over lowest-priority pick`);
        break;
      }
    }
  }

  const durationMs = Date.now() - start;
  console.log(`[EDITOR-IN-CHIEF] ✅ ${decisions.length} publications selected, ${triageResult.selected.length - decisions.length} budget-cut, ${topics.length - triageResult.selected.length} skipped in ${durationMs}ms ($${totalCost.toFixed(4)})`);

  return {
    decisions,
    skipped: topics.length - decisions.length,
    costUsd: totalCost,
    durationMs,
  };
}

// ============================================================================
// LLM TRIAGE — Single call to select and prioritize topics
// ============================================================================

interface TriageSelection {
  topicId: string;
  action: 'publish_signal' | 'publish_memo' | 'publish_brief' | 'publish_strategic' | 'monitor' | 'skip';
  reasoning: string;
  priority: number;
  researchQuestion?: string;
  intellectualAmbition?: number;  // 0-100 — how much the question challenges conventional thinking
  contrarianSignal?: number;      // 0-100 — strength of heterodox/contrarian angle
}

async function llmTriage(
  topics: RadarTopic[],
  recentTitles: string[],
  maxPubs: number,
  agenda?: ResearchAgendaContext
): Promise<{ selected: TriageSelection[]; costUsd: number }> {
  const topicSummaries = topics.slice(0, 15).map((t, i) => ({
    index: i,
    id: t.id,
    title: t.title,
    source: t.source,
    type: t.sourceType,
    score: t.score,
    signalStrength: t.signalStrength || 'emerging',
    vertical: t.vertical || 'unknown',
    age: getAgeLabel(t.publishedAt),
  }));

  const recentContext = recentTitles.length > 0
    ? `\nALREADY PUBLISHED (last 48h):\n${recentTitles.map(t => `- ${t}`).join('\n')}`
    : '\nNo recent publications.';

  try {
    const result = await callLLM({
      messages: [
        {
          role: 'system',
          content: `You are the Editor-in-Chief of NomosX — a revolutionary AI-powered think tank that does not merely summarize consensus but challenges it, crosses domains that others keep separate, and asks questions that conventional institutions are afraid to pose.

Your editorial DNA:
- COMBAT NOVLANGUE: Name things by their true name. When power renames repression as "reform," expose the linguistic deception.
- CONNECT IDEAS ACROSS DOMAINS: The most consequential insights live at the intersection of domains.
- MEANING BEFORE ANSWERS: Before producing a conclusion, establish what the question actually means.

SELECTION CRITERIA (in order of importance):
1. NOVELTY — Is this NEW? Skip anything already covered in recent publications.
2. URGENCY — Is this BREAKING? Time-sensitive events > evergreen analysis.
3. IMPACT — Will decision-makers care? Policy changes, crises, breakthroughs.
4. ANGLE — Can we add unique value with academic + news cross-referencing?
5. DIVERSITY — Don't over-cover one domain. Mix geopolitics, tech, climate, etc.
6. ACADEMIC TRACTABILITY — Can this topic be answered with existing academic literature? Avoid ultra-niche topics that have no research base. If the topic is too new or too specific for academic databases, skip it or reformulate to a broader question that HAS literature.
7. INTELLECTUAL AMBITION — Does this topic offer PARADIGM-SHIFTING insights? Prioritize:
   - Contrarian positions that challenge consensus
   - Interdisciplinary synthesis opportunities (topics spanning 2+ domains)
   - First-principles thinking over incremental updates
   - Topics that expose hidden assumptions or power dynamics
   - Topics that connect to deeper ontological/philosophical questions
8. CONTRARIAN SIGNAL — Does this topic challenge the mainstream narrative? Prioritize:
   - Topics where the consensus may be wrong
   - Topics where independent/dissident voices are raising alarms
   - Topics that reveal the gap between official discourse and structural reality

SIGNAL STRENGTH GUIDE:
- "breaking" (score ≥ 70): Strong multi-channel signal — prioritize these.
- "emerging" (score 45-69): Early signal worth investigating — select if the topic has strategic value, even if it's not yet mainstream news. Emerging topics often yield the most original analysis.
- "routine" (score < 45): Weak signal — only select if no better options exist and the topic has clear strategic relevance.

ACADEMIC TRACTABILITY CHECK (critical — prevents wasted pipeline runs):
Before selecting a topic, ask yourself: "Is there likely to be academic literature on this?" If the topic is about a very recent event with no academic coverage yet, reformulate the question to the underlying RESEARCHABLE issue. Examples:
- BAD: "What is the impact of the August 2026 Gaza digital currency pilot?" → too specific, no academic literature
- GOOD: "How do digital financial systems affect economic resilience in conflict-affected territories?"
- BAD: "What is the impact of [specific company]'s new AI product?" → no academic literature
- GOOD: "How does AI adoption affect productivity in [industry sector]?"
If you cannot reformulate to a question with likely academic literature, SKIP the topic.

ACTIONS (4 publication formats — each is a DIFFERENT EDITORIAL ANGLE, not a quality tier):
ALL formats share the SAME quality bar. The difference is PURPOSE and ANGLE, not rigor.

- "publish_signal" — Signal Brief (2-4 pages, 500-1,200 words, cost: $0.50, time: 1-2min)
  ANGLE: "Something important just happened" → ALERT
  PURPOSE: Inform the reader NOW with full rigor. What happened, why it matters, what to watch.
  CHOOSE THIS WHEN: New evidence emerged, significant data was released, a verifiable signal just appeared.
  DO NOT CHOOSE THIS FOR: Topics that need deep analysis or where a decision is pending.

- "publish_memo" — Decision Memo (4-8 pages, 1,200-2,500 words, cost: $1.50, time: 2-4min)
  ANGLE: "A decision is pending" → ACTION
  PURPOSE: Help the reader DECIDE. Context, key evidence, options, recommendation, risks.
  CHOOSE THIS WHEN: A policy change is underway, a regulatory decision is pending, a strategic fork exists.
  DO NOT CHOOSE THIS FOR: Pure information alerts or topics needing deep narrative analysis.

- "publish_brief" — Article (8-15 pages, 3,000-6,000 words, cost: $3, time: 3-5min)
  ANGLE: "This needs to be understood" → ANALYSIS
  PURPOSE: Deep comprehension. Narrative, nuance, multiple perspectives, what the evidence says.
  CHOOSE THIS WHEN: The topic is complex, evidence is contradictory, or understanding requires context.
  DO NOT CHOOSE THIS FOR: Breaking alerts (use Signal Brief) or pending decisions (use Decision Memo).

- "publish_strategic" — Strategic Report (20-50 pages, 8,000-20,000 words, cost: $10, time: 8-12min)
  ANGLE: "A structural shift is underway" → STRATEGY
  PURPOSE: Foresight and planning. Scenarios, stakeholder impact, roadmap for long-term preparation.
  CHOOSE THIS WHEN: A trend is breaking, a methodology is shifting, a paradigm change is visible.
  DO NOT CHOOSE THIS FOR: Routine analysis or single-event alerts.

- "monitor" — Not urgent enough now, but worth watching.
- "skip" — Not relevant, duplicate, or low-value.

FORMAT SELECTION IS ABOUT ANGLE, NOT QUALITY:
- The format choice reflects WHAT THE READER NEEDS from this topic, not how strong the signal is.
- A Signal Brief on a major finding is just as rigorous as a Strategic Report — it's shorter because the reader needs speed, not because the evidence is weaker.
- When in doubt, ask: "What does the reader need to DO with this?" → Inform (Signal) / Decide (Memo) / Understand (Article) / Plan (Strategic).

Select at most ${maxPubs} topics for publication. Be SELECTIVE but not OVERLY CONSERVATIVE — a think tank's value comes from covering emerging topics before they become mainstream, and from asking questions others won't.

CRITICAL — RESEARCH QUESTION REFORMULATION:
For each selected topic, reformulate the raw headline into an ANALYTICAL RESEARCH QUESTION. The pipeline searches academic databases with this question — a news headline yields poor academic matches.
Rules:
- Generalize the anecdote to the underlying policy/strategic issue
- Keep the geographic/temporal anchor when relevant
- Make it answerable with academic literature + primary data
- Use standard academic terminology that databases index well (avoid news jargon)
- One sentence, interrogative form
- INNOVATION: Where possible, frame the question in a way that CHALLENGES the conventional framing. Don't just ask "What is the impact of X?" — ask "Who benefits from framing this as an X problem?" or "What assumptions are hidden in the dominant discourse on X?" or "How does X connect to the deeper question of Y?"
- CROSS-DOMAIN: Where possible, frame the question to invite cross-domain insights. Don't just ask an economics question — ask how economics, anthropology, and philosophy intersect on this issue.

TOPIC REFERENCE: each topic has an "index" field (integer 0-${Math.min(15, topics.length) - 1}). Return THAT integer as "topicId" — do not copy the opaque "id" string, do not invent ids.

Return JSON: { "selections": [{ "topicId": <integer index>, "action": "publish_signal|publish_memo|publish_brief|publish_strategic|monitor|skip", "reasoning": "one sentence", "priority": 0-100, "researchQuestion": "analytical question reformulated from the headline", "intellectualAmbition": 0-100, "contrarianSignal": 0-100 }] }`
        },
        {
          role: 'user',
          content: `CANDIDATE TOPICS:\n${JSON.stringify(topicSummaries, null, 2)}${recentContext}${agenda?.promptBlock ?? ''}\n\nSelect the best topics for publication.`
        }
      ],
      temperature: 0.15,
      maxTokens: 1500,
      jsonMode: true,
      enableCache: true,
      task: 'editor_in_chief',
    });

    const parsed = parseJson<any>(result.content);
    if (!parsed) return { selected: [], costUsd: result.costUsd };
    const selections: TriageSelection[] = (parsed.selections || [])
      .filter((s: any) => s.action === 'publish_signal' || s.action === 'publish_memo' || s.action === 'publish_brief' || s.action === 'publish_strategic')
      .map((s: any) => ({
        topicId: s.topicId,
        action: s.action as TriageSelection['action'],
        reasoning: s.reasoning || '',
        priority: typeof s.priority === 'number' ? s.priority : 50,
        researchQuestion: s.researchQuestion,
        intellectualAmbition: typeof s.intellectualAmbition === 'number' ? s.intellectualAmbition : undefined,
        contrarianSignal: typeof s.contrarianSignal === 'number' ? s.contrarianSignal : undefined,
      }))
      .slice(0, maxPubs);

    return { selected: selections, costUsd: result.costUsd };
  } catch (err) {
    console.warn('[EDITOR-IN-CHIEF] LLM triage failed, falling back to source-type-based selection:', err);
    // Fallback: top N by score, with format selected by EDITORIAL ANGLE (sourceType)
    // NOT by quality — all formats share the same quality bar
    const fallback = topics.slice(0, maxPubs).map(t => {
      // Map sourceType → editorial angle → format
      let action: TriageSelection['action'] = 'publish_brief'; // analytical default
      if (t.sourceType === 'data' || t.sourceType === 'signal') {
        action = 'publish_signal'; // ALERT: something new emerged
      } else if (t.sourceType === 'policy' || t.sourceType === 'institutional') {
        action = 'publish_memo'; // ACTION: a decision is pending
      } else if (t.sourceType === 'news' || t.sourceType === 'think-tank') {
        action = 'publish_brief'; // ANALYSIS: this needs to be understood
      } else if (t.sourceType === 'academic') {
        action = 'publish_strategic'; // STRATEGY: structural shift from research
      }
      return {
        topicId: t.id,
        action,
        reasoning: 'Fallback: selected by source type angle',
        priority: t.score,
      };
    });
    return { selected: fallback, costUsd: 0 };
  }
}

// ============================================================================
// HELPERS
// ============================================================================

async function getRecentPublicationTitles(): Promise<string[]> {
  try {
    const cutoff = new Date(Date.now() - 48 * 60 * 60 * 1000);
    const pubs = await prisma.thinkTankPublication.findMany({
      where: { publishedAt: { gte: cutoff }, status: 'PUBLISHED' },
      select: { title: true },
      orderBy: { publishedAt: 'desc' },
      take: 20,
    });
    return pubs.map(p => p.title);
  } catch {
    return [];
  }
}

function getAgeLabel(date: Date | null): string {
  if (!date) return 'undated';
  const hours = (Date.now() - date.getTime()) / (1000 * 60 * 60);
  if (hours < 1) return 'just now';
  if (hours < 6) return `${Math.round(hours)}h ago`;
  if (hours < 24) return `${Math.round(hours)}h ago`;
  if (hours < 48) return 'yesterday';
  return `${Math.round(hours / 24)}d ago`;
}
