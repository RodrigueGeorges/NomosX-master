/**
 * NomosX Knowledge Graph + Experience Bank + Context Compression
 *
 * Three infrastructure innovations from 2026 research:
 *
 * 1. KNOWLEDGE GRAPH (Agents-K1, arxiv 2026):
 *    Converts papers into typed knowledge graphs with entities, claims,
 *    mechanisms, method lineages. Enables multi-hop reasoning.
 *
 * 2. EXPERIENCE BANK (TMAS, ICML 2026):
 *    Persistent memory of past analyses. Reusable conclusions, patterns,
 *    and guidelines that improve future runs.
 *
 * 3. CONTEXT COMPRESSION (IterResearch, ICLR 2026):
 *    Compresses intermediate findings to fit in context window.
 *    Enables 2048+ tool calls in 40k context.
 */

import { callLLM } from '../llm/unified-llm';
import { captureInputFifo } from './frozen-inputs';
import { parseJson } from './json-utils';

// ─── 1. Knowledge Graph Inter-Papers ────────────────────────────────────────

export interface KGEntity {
  id: string;
  name: string;
  type: 'method' | 'dataset' | 'metric' | 'concept' | 'organization' | 'person' | 'policy' | 'technology';
  aliases: string[];
  sourceIds: string[]; // Which sources mention this entity
}

export interface KGRelation {
  id: string;
  source: string; // Entity ID
  target: string; // Entity ID
  type: 'uses' | 'evaluates' | 'contradicts' | 'supports' | 'extends' | 'cites' | 'funds' | 'regulates' | 'measures';
  weight: number; // 0-1, confidence
  sourceId: string; // Which source this relation comes from
}

export interface KnowledgeGraph {
  entities: KGEntity[];
  relations: KGRelation[];
  clusters: Array<{ id: string; entityIds: string[]; label: string }>;
  bridges: Array<{ entityId: string; connectsClusters: string[] }>;
}

const KG_EXTRACTION_PROMPT = `You are a knowledge graph extractor. Extract entities and relations from research sources.

SOURCES:
{sources}

Extract:
1. ENTITIES: Methods, datasets, metrics, concepts, organizations, people, policies, technologies
2. RELATIONS: How entities relate to each other (uses, evaluates, contradicts, supports, extends, cites, funds, regulates, measures)

Return JSON:
{
  "entities": [
    {
      "id": "e1",
      "name": "Carbon Tax",
      "type": "policy",
      "aliases": ["carbon pricing", "CO2 tax"],
      "sourceIds": ["src1", "src3"]
    }
  ],
  "relations": [
    {
      "id": "r1",
      "source": "e1",
      "target": "e2",
      "type": "measures",
      "weight": 0.9,
      "sourceId": "src1"
    }
  ]
}

Rules:
- Merge entities that refer to the same thing (use aliases)
- Only extract relations that are explicitly stated in the sources
- Weight = confidence in the relation (0-1)`;

/**
 * Build a knowledge graph from a set of sources.
 * Extracts entities and relations using LLM, then detects clusters and bridges.
 */
export async function buildKnowledgeGraph(
  sources: Array<{ id: string; title: string; abstract: string }>,
): Promise<{ graph: KnowledgeGraph; costUsd: number }> {
  if (sources.length === 0) {
    return { graph: { entities: [], relations: [], clusters: [], bridges: [] }, costUsd: 0 };
  }

  try {
    // Process in batches of 10 sources
    const BATCH = 10;
    const allEntities: KGEntity[] = [];
    const allRelations: KGRelation[] = [];
    let totalCost = 0;

    for (let i = 0; i < sources.length; i += BATCH) {
      const batch = sources.slice(i, i + BATCH);
      const sourcesJson = JSON.stringify(batch.map(s => ({ id: s.id, title: s.title, abstract: s.abstract.slice(0, 500) })));

      const response = await callLLM({
        messages: [{ role: 'user', content: KG_EXTRACTION_PROMPT.replace('{sources}', sourcesJson) }],
        temperature: 0.1,
        jsonMode: true,
        maxTokens: 3000,
        task: 'reader_v3',
        enableCache: true,
      });
      totalCost += response.costUsd || 0;

      const result = parseJson<{ entities: KGEntity[]; relations: KGRelation[] }>(response.content);
      if (Array.isArray(result?.entities)) {
        for (const e of result.entities) {
          const n = normalizeKGEntity(e);
          if (n) allEntities.push(n);
        }
      }
      if (Array.isArray(result?.relations)) allRelations.push(...result.relations);
    }

    // Merge duplicate entities (by name similarity)
    const mergedEntities = mergeEntities(allEntities);
    const mergedRelations = mergeRelations(allRelations, allEntities, mergedEntities);

    // Detect clusters (groups of densely connected entities)
    const clusters = detectKGClusters(mergedEntities, mergedRelations);

    // Detect bridges (entities that connect multiple clusters)
    const bridges = detectKGBridges(mergedEntities, clusters);

    console.log(`[KG] Built graph: ${mergedEntities.length} entities, ${mergedRelations.length} relations, ${clusters.length} clusters, ${bridges.length} bridges`);

    return {
      graph: { entities: mergedEntities, relations: mergedRelations, clusters, bridges },
      costUsd: totalCost,
    };
  } catch (err) {
    console.warn('[KG] Build failed:', String(err).slice(0, 80));
    return { graph: { entities: [], relations: [], clusters: [], bridges: [] }, costUsd: 0 };
  }
}

function toStringArray(v: unknown): string[] {
  if (Array.isArray(v)) return v.filter((x): x is string => typeof x === 'string' && x.length > 0);
  if (typeof v === 'string' && v.length > 0) return [v];
  return [];
}

export function normalizeKGEntity(e: unknown): KGEntity | null {
  if (!e || typeof e !== 'object') return null;
  const o = e as Partial<KGEntity>;
  if (typeof o.name !== 'string' || o.name.trim().length === 0) return null;
  const type = (['method', 'dataset', 'metric', 'concept', 'organization', 'person', 'policy', 'technology'] as const)
    .includes(o.type as KGEntity['type']) ? o.type as KGEntity['type'] : 'concept';
  return {
    id: typeof o.id === 'string' && o.id ? o.id : `e-${o.name.toLowerCase().replace(/\s+/g, '-')}`,
    name: o.name.trim(),
    type,
    aliases: toStringArray(o.aliases),
    sourceIds: toStringArray(o.sourceIds),
  };
}

function mergeEntities(entities: KGEntity[]): KGEntity[] {
  const merged: KGEntity[] = [];
  const seen = new Map<string, KGEntity>();

  for (const entity of entities) {
    const key = entity.name.toLowerCase().trim();
    const existing = seen.get(key);
    if (existing) {
      // Merge aliases and source IDs
      existing.aliases = [...new Set([...existing.aliases, ...entity.aliases])];
      existing.sourceIds = [...new Set([...existing.sourceIds, ...entity.sourceIds])];
    } else {
      seen.set(key, { ...entity });
      merged.push({ ...entity });
    }
  }

  return merged;
}

function mergeRelations(
  relations: KGRelation[],
  originalEntities: KGEntity[],
  mergedEntities: KGEntity[],
): KGRelation[] {
  // Simple dedup by source+target+type
  const seen = new Set<string>();
  return relations.filter(r => {
    const key = `${r.source}|${r.target}|${r.type}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function detectKGClusters(entities: KGEntity[], relations: KGRelation[]): Array<{ id: string; entityIds: string[]; label: string }> {
  // Simple clustering: group entities by type
  const byType = new Map<string, string[]>();
  for (const e of entities) {
    if (!byType.has(e.type)) byType.set(e.type, []);
    byType.get(e.type)!.push(e.id);
  }

  return Array.from(byType.entries()).map(([type, ids], i) => ({
    id: `cluster_${i}`,
    entityIds: ids,
    label: type,
  }));
}

function detectKGBridges(entities: KGEntity[], clusters: Array<{ id: string; entityIds: string[] }>): Array<{ entityId: string; connectsClusters: string[] }> {
  // Find entities that appear in multiple clusters' source IDs
  const entityClusters = new Map<string, Set<string>>();
  for (const cluster of clusters) {
    for (const entityId of cluster.entityIds) {
      if (!entityClusters.has(entityId)) entityClusters.set(entityId, new Set());
      entityClusters.get(entityId)!.add(cluster.id);
    }
  }

  const bridges: Array<{ entityId: string; connectsClusters: string[] }> = [];
  for (const [entityId, clusterIds] of entityClusters) {
    if (clusterIds.size >= 2) {
      bridges.push({ entityId, connectsClusters: Array.from(clusterIds) });
    }
  }

  return bridges;
}

// ─── 2. Experience Bank ─────────────────────────────────────────────────────

export interface ExperienceEntry {
  id: string;
  topic: string;
  question: string;
  phase: string;
  insight: string;
  pattern: string; // Reusable pattern
  successMetric?: number;
  /** When this experience applies — survey-backed applicability condition. */
  appliesWhen?: string;
  timestamp: number;
}

export interface GuidelineEntry {
  id: string;
  topic: string;
  guideline: string;
  rationale: string;
  /** Outcome the guideline was extracted from (0-1) — reliability weight. */
  successMetric?: number;
  /** Conditions under which the guideline applies. */
  appliesWhen?: string;
  timestamp: number;
}

// In-memory experience bank — the fast path. Every write is mirrored to
// agentAuditLog (same durable store as durable-execution and the persistent
// signal bus) so the bank survives process restarts and is shared across
// workers: a crash no longer erases what the system learned.
const experienceBank: ExperienceEntry[] = [];
const guidelineBank: GuidelineEntry[] = [];
const MAX_BANK_SIZE = 200;
const AUDIT_AGENT = 'experience_bank';
const EXP_ACTION = 'EXPERIENCE_RECORD';
const GUIDE_ACTION = 'GUIDELINE_RECORD';
let rehydration: Promise<void> | null = null;

function persistEntry(action: string, id: string, entry: unknown): void {
  import('../db').then(({ prisma }) =>
    prisma.agentAuditLog.create({
      select: { id: true },
      data: {
        agent: AUDIT_AGENT,
        action,
        resource: id,
        metadata: JSON.stringify(entry),
        timestamp: new Date(),
      },
    }),
  ).then(() => undefined).catch(() => undefined); // fire-and-forget — never block the pipeline
}

/**
 * Load persisted entries into the in-memory banks once per process. Entries
 * already in memory (same id) are skipped — a restart rehydrates instead of
 * duplicating. Lazy + guarded so concurrent callers share one DB read.
 */
async function ensureBankHydrated(): Promise<void> {
  if (!rehydration) {
    rehydration = (async () => {
      const { prisma } = await import('../db');
      const rows = await prisma.agentAuditLog.findMany({
        where: { agent: AUDIT_AGENT, action: { in: [EXP_ACTION, GUIDE_ACTION] } },
        orderBy: { timestamp: 'desc' },
        take: MAX_BANK_SIZE * 2,
        select: { action: true, metadata: true },
      });
      const expIds = new Set(experienceBank.map(e => e.id));
      const guideIds = new Set(guidelineBank.map(g => g.id));
      for (const row of rows.reverse()) {
        try {
          const entry = JSON.parse(row.metadata || '{}');
          if (row.action === EXP_ACTION && entry.id && !expIds.has(entry.id)) {
            experienceBank.push(entry); expIds.add(entry.id);
          } else if (row.action === GUIDE_ACTION && entry.id && !guideIds.has(entry.id)) {
            guidelineBank.push(entry); guideIds.add(entry.id);
          }
        } catch { /* skip malformed row */ }
      }
      if (experienceBank.length > MAX_BANK_SIZE) experienceBank.splice(0, experienceBank.length - MAX_BANK_SIZE);
      if (guidelineBank.length > MAX_BANK_SIZE) guidelineBank.splice(0, guidelineBank.length - MAX_BANK_SIZE);
    })().catch(() => undefined);
  }
  return rehydration;
}

export function recordExperience(
  topic: string,
  question: string,
  phase: string,
  insight: string,
  pattern: string,
  successMetric?: number,
  appliesWhen?: string,
): void {
  const entry: ExperienceEntry = {
    id: `exp_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    topic,
    question,
    phase,
    insight,
    pattern,
    successMetric,
    appliesWhen,
    timestamp: Date.now(),
  };
  experienceBank.push(entry);
  if (experienceBank.length > MAX_BANK_SIZE) {
    experienceBank.splice(0, experienceBank.length - MAX_BANK_SIZE);
  }
  persistEntry(EXP_ACTION, entry.id, entry);
}

export function recordGuideline(topic: string, guideline: string, rationale: string, successMetric?: number, appliesWhen?: string): void {
  const entry: GuidelineEntry = {
    id: `guide_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    topic,
    guideline,
    rationale,
    successMetric,
    appliesWhen,
    timestamp: Date.now(),
  };
  guidelineBank.push(entry);
  if (guidelineBank.length > MAX_BANK_SIZE) {
    guidelineBank.splice(0, guidelineBank.length - MAX_BANK_SIZE);
  }
  persistEntry(GUIDE_ACTION, entry.id, entry);
}

/** Distinctive-token overlap — same approach as prediction-watch triggers.
 * Substring matching on a 20-char prefix fails on paraphrases ("EU battery
 * policy" vs "How do batteries reshape the grid?"); overlap ≥2 distinctive
 * tokens catches the same topic reworded. */
function topicOverlap(a: string, b: string): boolean {
  const tokens = (s: string) => new Set(s.toLowerCase().split(/\W+/).filter(t => t.length > 4));
  const aT = tokens(a), bT = tokens(b);
  let shared = 0;
  for (const t of aT) if (bT.has(t)) shared++;
  return shared >= 2;
}

export async function getRelevantExperience(topic: string, phase: string): Promise<ExperienceEntry[]> {
  await ensureBankHydrated();
  // Reliability-weighted retrieval (experience-memory survey 2026): entries
  // extracted from stronger outcomes rank above weaker ones; unscored legacy
  // entries sit at a neutral 0.5 so they neither dominate nor vanish.
  return experienceBank
    .filter(e => e.phase === phase && topicOverlap(e.topic, topic))
    .sort((a, b) => (b.successMetric ?? 0.5) - (a.successMetric ?? 0.5) || b.timestamp - a.timestamp)
    .slice(0, 5);
}

export async function getRelevantGuidelines(topic: string): Promise<GuidelineEntry[]> {
  await ensureBankHydrated();
  return guidelineBank
    .filter(g => topicOverlap(g.topic, topic))
    .sort((a, b) => (b.successMetric ?? 0.5) - (a.successMetric ?? 0.5) || b.timestamp - a.timestamp)
    .slice(0, 3);
}

/**
 * Extract experience and guidelines from a completed pipeline run.
 */
export async function extractExperience(
  topic: string,
  question: string,
  pipelineStats: any,
): Promise<{ costUsd: number }> {
  let totalCost = 0;

  try {
    // Post-gate learning call — freeze response for record/replay parity.
    const response = await captureInputFifo('learning:experience', () => callLLM({
      messages: [{
        role: 'user',
        content: `You are a meta-learner. Extract reusable experience and guidelines from a completed research pipeline run.

TOPIC: ${topic}
QUESTION: ${question}
PIPELINE STATS: ${JSON.stringify(pipelineStats).slice(0, 2000)}

Extract:
1. EXPERIENCES: What worked well? What didn't? What patterns emerged?
2. GUIDELINES: What rules should future runs follow for similar topics?

For EACH item also state "appliesWhen": the concrete conditions under which
this lesson transfers to a future run (topic type, evidence regime, failure
mode). A lesson without applicability conditions is noise — only extract
patterns you can bound.

Return JSON:
{
  "experiences": [
    {
      "phase": "scout",
      "insight": "OpenAlex returned 400+ sources but most were off-topic",
      "pattern": "For policy topics, prefer Crossref + institutional providers over OpenAlex",
      "appliesWhen": "Policy/geopolitics questions with broad multi-domain vocabularies"
    }
  ],
  "guidelines": [
    {
      "guideline": "For controversial topics, always include contrarian lens",
      "rationale": "Without contrarian sources, analysis has confirmation bias",
      "appliesWhen": "Contested or polarized research questions"
    }
  ]
}`,
      }],
      temperature: 0.3,
      jsonMode: true,
      maxTokens: 1500,
      task: 'reader_v3',
      enableCache: true,
    }));
    totalCost += response.costUsd || 0;

    const result = parseJson<{ experiences: Array<{ phase: string; insight: string; pattern: string; appliesWhen?: string }>; guidelines: Array<{ guideline: string; rationale: string; appliesWhen?: string }> }>(response.content);

    // Reliability of the source run: published > held > failed, refined by
    // the deterministic trust score when present. Lessons from a held run
    // still teach (the hold reasons ARE the lesson) but rank below lessons
    // from a clean publish.
    const outcome = pipelineStats?.outcome ?? {};
    const trust = typeof outcome.trustScore === 'number' ? outcome.trustScore / 100 : null;
    const statusBase = outcome.status === 'published' ? 0.9 : outcome.status === 'held' ? 0.55 : 0.3;
    const successMetric = trust != null ? Math.min(1, Math.max(0.1, (statusBase + trust) / 2)) : statusBase;

    if (result?.experiences) {
      for (const exp of result.experiences) {
        recordExperience(topic, question, exp.phase, exp.insight, exp.pattern, successMetric, exp.appliesWhen);
      }
    }

    if (result?.guidelines) {
      for (const g of result.guidelines) {
        recordGuideline(topic, g.guideline, g.rationale, successMetric, g.appliesWhen);
      }
    }

    // DA-objection bank: the adversarial reviewer's fatal/major challenges
    // are the highest-signal lessons the system produces — they name the
    // exact argumentation modes that kill a draft. Record them
    // deterministically (no LLM) under phase 'da-objection' so Pass 2 can
    // stress-test against them BEFORE drafting, not only repair after.
    const daChallenges = (pipelineStats?.devilsAdvocate?.topChallenges ?? []) as Array<{ type?: string; text?: string }>;
    let daRecorded = 0;
    for (const ch of daChallenges.slice(0, 3)) {
      const text = String(ch?.text ?? '').trim().slice(0, 400);
      if (text.length < 20) continue;
      recordExperience(
        topic, question, 'da-objection',
        `Adversarial ${ch?.type ?? 'challenge'} objection: ${text}`,
        text,
        successMetric,
        'Analyses in this domain — pre-empt this objection class during mechanism stress-testing',
      );
      daRecorded++;
    }
    if (daRecorded > 0) {
      console.log(`[ExperienceBank] Recorded ${daRecorded} DA objection(s) for future P2 stress tests`);
    }

    console.log(`[ExperienceBank] Extracted ${result?.experiences?.length || 0} experiences, ${result?.guidelines?.length || 0} guidelines`);
  } catch (err) {
    console.warn('[ExperienceBank] Extraction failed:', String(err).slice(0, 80));
  }

  return { costUsd: totalCost };
}

// ─── 3. Context Compression ─────────────────────────────────────────────────

const COMPRESSION_PROMPT = `You are a context compressor. Compress a set of research findings into a concise summary that preserves key information.

FINDINGS TO COMPRESS:
{findings}

TARGET LENGTH: {targetLength} words

Compress by:
1. Removing redundant information
2. Keeping only key claims, statistics, and citations
3. Preserving the structure (sections, headings)
4. Maintaining all citation tags [SRC-N]

Return the compressed text only (no JSON, no metadata).`;

/**
 * Compress intermediate findings to fit in context window.
 * This is the IterResearch pattern: compress between phases to enable
 * long-horizon pipelines within limited context.
 */
export async function compressContext(
  findings: string,
  targetLengthWords: number = 500,
): Promise<{ compressed: string; costUsd: number }> {
  // If already short enough, return as-is
  const currentWords = findings.split(/\s+/).length;
  if (currentWords <= targetLengthWords) {
    return { compressed: findings, costUsd: 0 };
  }

  try {
    const response = await callLLM({
      messages: [{
        role: 'user',
        content: COMPRESSION_PROMPT
          .replace('{findings}', findings.slice(0, 12000))
          .replace('{targetLength}', String(targetLengthWords)),
      }],
      temperature: 0.1,
      maxTokens: targetLengthWords * 2, // Tokens ≈ 1.5x words
      task: 'reader_v3',
      enableCache: true,
    });

    const compressed = response.content.trim();
    const compressedWords = compressed.split(/\s+/).length;
    console.log(`[ContextCompress] ${currentWords} → ${compressedWords} words (${Math.round((1 - compressedWords / currentWords) * 100)}% reduction)`);

    return { compressed, costUsd: response.costUsd || 0 };
  } catch (err) {
    console.warn('[ContextCompress] Failed:', String(err).slice(0, 80));
    // Fallback: simple truncation
    return { compressed: findings.slice(0, targetLengthWords * 6), costUsd: 0 };
  }
}

/**
 * Compress multiple readings into a single summary.
 */
export async function compressReadings(
  readings: Array<{ sourceId: string; claims: string[]; methods: string[]; results: string[]; limitations: string[] }>,
): Promise<{ compressed: string; costUsd: number }> {
  const readingsText = readings.map(r =>
    `Source ${r.sourceId}:\n` +
    `  Claims: ${r.claims.join('; ')}\n` +
    `  Methods: ${r.methods.join('; ')}\n` +
    `  Results: ${r.results.join('; ')}\n` +
    `  Limitations: ${r.limitations.join('; ')}`
  ).join('\n\n');

  return compressContext(readingsText, 800);
}
