/**
 * Claim Grounding Gate — deterministic claim-to-source verification.
 *
 * Inspired by:
 * - groundrails (stellarshenson): deterministic lexical grounding, no LLM, CPU-only
 * - warrant (eburke21): decompose answer into atomic claims, verify each against sources
 * - sourcecheck (aberaio): resolve citation to real source, check claim appears in source text
 * - DeepCitation: deterministic verification layer for AI citations
 *
 * Pipeline:
 * 1. DECOMPOSE: Extract sentences from HTML, split into atomic claims
 * 2. MAP: Each claim → its [SRC-N] citation
 * 3. GROUND: Lexically verify the claim content appears in the cited source
 * 4. VERDICT: supported / partial / unsupported / uncited
 * 5. REPAIR: Remove or flag unsupported claims
 *
 * This is deterministic — no LLM in the loop. It runs on CPU in milliseconds.
 * It catches the most egregious hallucinations: claims that cite a source
 * but whose content doesn't appear anywhere in that source's text.
 *
 * Key insight from RAGTruth benchmark: deterministic lexical grounding
 * catches ~76% of hallucinations (macro-F1) without any model call.
 * Adding semantic escalation catches ~82%. We implement the lexical pass
 * first; semantic escalation can be added later via HHEM/MiniCheck.
 */

// ─── Types ──────────────────────────────────────────────────────────────────

export type ClaimVerdict = 'supported' | 'partial' | 'unsupported' | 'uncited' | 'contradicted';

export interface AtomicClaim {
  text: string;
  sentenceIndex: number;
  sourceRef: number | null; // [SRC-N] number, or null if uncited
  sourceRefTag: string | null; // [SRC-N] tag as it appears
  verdict: ClaimVerdict;
  evidenceSnippet: string | null;
  score: number; // 0-1, lexical overlap score
}

export interface GroundingResult {
  claims: AtomicClaim[];
  supported: number;
  partial: number;
  unsupported: number;
  uncited: number;
  contradicted: number;
  total: number;
  groundedness: number; // (supported + partial) / total
  strictGroundedness: number; // max(0, (supported - contradicted) / total)
  html: string; // repaired HTML with unsupported claims removed/flagged
  removedClaims: number;
  details: string[];
}

// ─── 1. CLAIM DECOMPOSITION ─────────────────────────────────────────────────
/**
 * Extract sentences from HTML text content and identify atomic claims.
 * Each sentence with a [SRC-N] tag is a claim that needs grounding.
 */

function extractSentencesFromHtml(html: string): { text: string; raw: string; startIdx: number }[] {
  // Convert <sup class="cite"><a href="#ref-N" data-evidence="EN">EN</a></sup> to [SRC-N]
  // so that decomposeIntoClaims can find citations after tag stripping.
  let normalized = html.replace(
    /<sup class="cite"><a href="#ref-(\d+)"[^>]*>[^<]*<\/a><\/sup>/g,
    '[SRC-$1]'
  );
  // Also convert standalone <a href="#ref-N"> to [SRC-N]
  normalized = normalized.replace(/<a href="#ref-(\d+)"[^>]*>[^<]*<\/a>/g, '[SRC-$1]');
  // Handle HTML-escaped sup tags (safety net — should not occur after editor-agent fix,
  // but just in case other renderers produce escaped tags)
  normalized = normalized.replace(
    /&lt;sup class=&quot;cite&quot;&gt;&lt;a href=&quot;#ref-(\d+)&quot;[^&]*&gt;[^&]*&lt;\/a&gt;&lt;\/sup&gt;/g,
    '[SRC-$1]'
  );
  // Normalize [E-N] evidence IDs to [SRC-N] (strategic reports use E-N format)
  normalized = normalized.replace(/\[E(\d+)\]/g, '[SRC-$1]');

  // Repair unclosed <style>/<script>/<head> blocks found in some stored
  // publications: an unclosed <style> swallows all prose (extraction = 0).
  // Close the block right before the first prose tag so stripping works.
  normalized = normalized.replace(
    /<(style|script)\b[^>]*>(?![\s\S]*<\/\1>)([\s\S]*?)(?=<(?:p|h[1-6]|section|article|body|div)\b)/gi,
    '<$1>$2</$1>',
  );
  normalized = normalized.replace(
    /<head\b[^>]*>(?![\s\S]*<\/head>)([\s\S]*?)(?=<(?:p|h[1-6]|section|article|body|div)\b)/gi,
    '<head>$1</head>',
  );

  // Strip non-prose blocks first — CSS/JS/head content produces garbage
  // "sentences" (rgba alphas, hex colors) that pollute claim extraction and
  // can trigger destructive removals inside markup.
  normalized = normalized
    .replace(/<(style|script|head)\b[^>]*>[\s\S]*?(<\/\1>|(?=<body\b)|(?=<article\b)|$)/gi, ' ');

  // data-no-cite elements are the institute's own editorial apparatus (model
  // estimates, scenario metadata, horizon/confidence spans) — they are not
  // source-groundable claims and must never enter claim extraction. A live
  // run was HELD because grounding deleted the central-scenario horizon.
  normalized = normalized.replace(
    /<([a-z][a-z0-9-]*)\b[^>]*\bdata-no-cite\b[^>]*>[\s\S]*?<\/\1>/gi,
    ' '
  );

  // Strip HTML tags to get text content, keeping [SRC-N] markers
  const text = normalized.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();

  // Split into sentences (keep [SRC-N] with the sentence).
  // CRITICAL: Don't split on '.' between digits (decimal points like "0.5" or "27.31").
  // \.(?=\d) matches a decimal point and treats it as part of the sentence content.
  const sentences: { text: string; raw: string; startIdx: number }[] = [];
  const sentenceRegex = /(?:[^.!?]|\.(?=\d))+[.!?]*/g;
  let match;
  while ((match = sentenceRegex.exec(text)) !== null) {
    const sentence = match[0].trim();
    if (sentence.length > 15) {
      sentences.push({
        text: sentence,
        raw: match[0],
        startIdx: match.index,
      });
    }
  }
  return sentences;
}

/**
 * Decompose a sentence into atomic claims.
 * An atomic claim is a simple factual assertion that can be verified independently.
 * We keep it simple: each sentence with a [SRC-N] is one atomic claim.
 * (Full decomposition with pronoun resolution would need an LLM — we stay deterministic.)
 */
/**
 * Reference-list fragment detection — bibliography tails like
 * "org/10.3390/bdcc8040042 [9] (2024)" or "respol.2023.104765 [2] Swiderska, K."
 * are extraction noise, not claims: they contain years/numbers (factual
 * markers) but assert nothing. Verified waste in production: they consumed
 * the SAFE verification budget and inflated the unsupported count.
 */
function isReferenceFragment(text: string): boolean {
  const s = text.trim();
  return /^(org|doi|www|https?)[\/:.]/i.test(s) ||           // "org/10.3390/..."
         /^[a-z]{2,25}\.\d{4}\./i.test(s) ||                 // "respol.2023.104765"
         /^[a-z]{2,10}\.\d{5,}/i.test(s) ||                  // "pwat.0000602", "pone.0330032", "thesis.83336"
         /^v\d+i\d+\.\d+/i.test(s) ||                        // "v14i4.6328"
         /^[a-z]{2,4}\/(?:handle|project|portal|detail|page|projects|converis)\//i.test(s) || // "edu/handle/1721.1/163428"
         /^id=[\w%]/i.test(s) ||                             // "id=10.1371%2Fjournal"
         /^\[\d+\]\s*[A-ZÀ-Þ]/.test(s) ||                    // "[9] Author, X."
         /^\d{1,3}\s+[A-ZÀ-Þ][a-zà-ÿ-]+,\s*[A-Z]\./.test(s) || // "9 Author, X."
         /^et al\.?[\s,]/i.test(s) ||
         (/\bdoi\b|10\.\d{4,9}\//i.test(s) && s.length < 120);
}

function decomposeIntoClaims(
  sentences: { text: string; raw: string; startIdx: number }[],
): AtomicClaim[] {
  const claims: AtomicClaim[] = [];

  sentences.forEach((sent, idx) => {
    // Skip reference-list fragments — not claims, just citation metadata
    if (isReferenceFragment(sent.text)) return;

    // Find [SRC-N] references in the sentence
    const srcMatches = [...sent.text.matchAll(/\[SRC-(\d+)\]/g)];

    if (srcMatches.length === 0) {
      // Uncited sentence — only flag if it contains factual assertions (numbers, dates)
      const hasFactualMarker = /\d+\.?\d*\s*%|\$\s?\d+|\b\d{4}\b|\b\d+[.,]?\d*\s*(?:billion|million|thousand)\b/i.test(sent.text);
      if (hasFactualMarker) {
        claims.push({
          text: sent.text.replace(/\[SRC-\d+\]/g, '').trim(),
          sentenceIndex: idx,
          sourceRef: null,
          sourceRefTag: null,
          verdict: 'uncited',
          evidenceSnippet: null,
          score: 0,
        });
      }
    } else {
      // Cited sentence — extract the primary source
      const primarySrc = parseInt(srcMatches[0][1], 10);
      claims.push({
        text: sent.text.replace(/\[SRC-\d+\]/g, '').trim(),
        sentenceIndex: idx,
        sourceRef: primarySrc,
        sourceRefTag: srcMatches[0][0],
        verdict: 'unsupported', // default, will be updated by grounding
        evidenceSnippet: null,
        score: 0,
      });
    }
  });

  return claims;
}

// ─── 2. LEXICAL GROUNDING ───────────────────────────────────────────────────
/**
 * Ground each claim against its cited source using lexical overlap.
 *
 * Inspired by groundrails' "composite" checker:
 * - SUPPORTED only when the claim appears near-verbatim in the source,
 *   with every number present and no polarity mismatch.
 * - Partial when key terms overlap but not near-verbatim.
 * - Unsupported when overlap is below threshold.
 *
 * This is precision-first: it abstains (unsupported) rather than guessing.
 */

function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter(t => t.length > 2 && !STOP_WORDS.has(t));
}

const STOP_WORDS = new Set([
  'the', 'and', 'for', 'are', 'but', 'not', 'you', 'all', 'can', 'her', 'was',
  'one', 'our', 'out', 'has', 'have', 'had', 'his', 'how', 'its', 'may', 'more',
  'most', 'new', 'now', 'old', 'see', 'way', 'who', 'did', 'get', 'let', 'say',
  'she', 'too', 'use', 'this', 'that', 'with', 'from', 'they', 'will', 'would',
  'there', 'their', 'what', 'about', 'which', 'when', 'your', 'said', 'were',
  'been', 'than', 'them', 'these', 'those', 'into', 'also', 'such', 'very',
  'only', 'some', 'any', 'each', 'other', 'then', 'thus', 'where', 'while',
  'should', 'could', 'between', 'through', 'during', 'before', 'after',
]);

function extractKeyTerms(text: string): Set<string> {
  return new Set(tokenize(text));
}

function extractNumbers(text: string): string[] {
  const numbers: string[] = [];
  const patterns = [
    /\d+\.?\d*\s*%/g,
    /\$\s?\d+\.?\d*\s*[BbMmKk]/g,
    /\b\d+\.?\d*\s*(?:billion|million|thousand)\b/gi,
    /\b\d{4}\b/g, // years
    /\b\d+[.,]?\d*\b/g, // generic numbers
  ];
  for (const p of patterns) {
    for (const m of text.matchAll(p)) {
      numbers.push(m[0].toLowerCase().replace(/\s+/g, ''));
    }
  }
  return numbers;
}

function lexicalGrounding(
  claim: AtomicClaim,
  sourceText: string,
): { verdict: ClaimVerdict; score: number; evidenceSnippet: string | null } {
  if (!sourceText || sourceText.length < 20) {
    return { verdict: 'unsupported', score: 0, evidenceSnippet: null };
  }

  const claimTerms = extractKeyTerms(claim.text);
  const sourceTerms = extractKeyTerms(sourceText);

  // Compute term overlap (Jaccard-like)
  let overlap = 0;
  for (const term of claimTerms) {
    if (sourceTerms.has(term)) overlap++;
  }
  const unigramScore = claimTerms.size > 0 ? overlap / claimTerms.size : 0;

  // Bigram overlap: catches phrase-level matches that unigram Jaccard misses
  const claimBigrams = extractBigrams(claim.text);
  const sourceBigrams = extractBigrams(sourceText);
  let bigramOverlap = 0;
  for (const bg of claimBigrams) {
    if (sourceBigrams.has(bg)) bigramOverlap++;
  }
  const bigramScore = claimBigrams.size > 0 ? bigramOverlap / claimBigrams.size : 0;

  // Composite score: weighted blend of unigram and bigram overlap
  const score = unigramScore * 0.6 + bigramScore * 0.4;

  // Number check: every number in the claim must appear in the source
  const claimNumbers = extractNumbers(claim.text);
  let numbersMatched = 0;
  for (const num of claimNumbers) {
    if (sourceText.toLowerCase().includes(num)) {
      numbersMatched++;
    }
  }
  const numbersOk = claimNumbers.length === 0 || numbersMatched === claimNumbers.length;

  // Polarity check: only flag as contradicted when there's a STRONG negation mismatch
  // (both have meaningful overlap AND one explicitly negates while the other affirms)
  const NEG_RE = /\b(not|no|never|without)\b/i;
  const claimNegated = NEG_RE.test(claim.text);
  const sourceNegated = NEG_RE.test(sourceText);
  // Only trigger polarity mismatch when score is high enough to be meaningful
  // AND one is explicitly negated while the other is explicitly affirmative
  const polarityMismatch = claimNegated !== sourceNegated && score > 0.4 && (claimNegated || sourceNegated);

  // Find best matching sentence in source for evidence snippet
  let evidenceSnippet: string | null = null;
  const sourceSentences = sourceText.split(/(?<=[.!?])\s+/);
  let bestSentScore = 0;
  for (const sSent of sourceSentences) {
    const sTerms = extractKeyTerms(sSent);
    let sOverlap = 0;
    for (const term of claimTerms) {
      if (sTerms.has(term)) sOverlap++;
    }
    const sScore = claimTerms.size > 0 ? sOverlap / claimTerms.size : 0;
    if (sScore > bestSentScore) {
      bestSentScore = sScore;
      evidenceSnippet = sSent.slice(0, 200);
    }
  }

  // Verdict logic — calibrated for paraphrased strategic analysis
  // (not verbatim quoting): lower thresholds reflect that think-tank
  // analysis synthesizes and reformulates, not copies.
  if (polarityMismatch) {
    return { verdict: 'contradicted', score, evidenceSnippet };
  }
  if (score >= 0.35 && numbersOk && bestSentScore >= 0.3) {
    return { verdict: 'supported', score, evidenceSnippet };
  }
  if (score >= 0.15 && numbersOk) {
    return { verdict: 'partial', score, evidenceSnippet };
  }
  // If we have any meaningful overlap at all, don't call it unsupported —
  // call it partial. Only truly zero-overlap claims are unsupported.
  if (score >= 0.08) {
    return { verdict: 'partial', score, evidenceSnippet };
  }
  return { verdict: 'unsupported', score, evidenceSnippet };
}

/**
 * Extract bigrams (consecutive word pairs) for phrase-level matching.
 * More robust than unigram Jaccard for detecting paraphrased claims.
 */
function extractBigrams(text: string): Set<string> {
  const tokens = tokenize(text);
  const bigrams = new Set<string>();
  for (let i = 0; i < tokens.length - 1; i++) {
    bigrams.add(`${tokens[i]}_${tokens[i + 1]}`);
  }
  return bigrams;
}

// ─── 3. CLAIM REPAIR ────────────────────────────────────────────────────────
/**
 * Remove unsupported claims from HTML or flag them.
 * We replace the sentence with a neutral marker rather than deleting entirely
 * (to preserve paragraph structure).
 */

export function repairHtmlWithGrounding(
  html: string,
  claims: AtomicClaim[],
  mode: 'remove' | 'flag' = 'flag',
): { html: string; removedClaims: number; details: string[] } {
  let removedClaims = 0;
  const details: string[] = [];

  // Find sentences that are unsupported or contradicted
  // Also find uncited claims with quantitative content (numbers, percentages) — these are the most dangerous hallucinations
  const badClaims = claims.filter(c =>
    c.verdict === 'unsupported' ||
    c.verdict === 'contradicted' ||
    (c.verdict === 'uncited' && /\d+\s*%|\d{4,}|\$\s*\d|million|billion|trillion/i.test(c.text))
  );
  if (badClaims.length === 0) {
    return { html, removedClaims: 0, details };
  }

  // Mask non-prose regions (<style>, <script>, <head>, references) so claim
  // fragments can never match inside CSS/markup and sentence-boundary
  // detection can't delete structural tags like </style> or </head>.
  const maskedBlocks: string[] = [];
  const maskRe = /<(style|script|head)\b[^>]*>[\s\S]*?(<\/\1>|(?=<body\b)|(?=<article\b)|$)/gi;
  let workingHtml = html.replace(maskRe, (m) => {
    maskedBlocks.push(m);
    return `\x00MASK${maskedBlocks.length - 1}\x00`;
  });
  // Editorial-decision blocks are the institute's own position, not source
  // claims — the publication gate requires the central scenario to render
  // verbatim from the persisted decision, so sentence-level removal inside it
  // can only break the gate, never improve grounding.
  workingHtml = workingHtml.replace(
    /<section\b[^>]*class="[^"]*\bcentral-scenario\b[^"]*"[^>]*>[\s\S]*?<\/section>/gi,
    (m) => { maskedBlocks.push(m); return `\x00MASK${maskedBlocks.length - 1}\x00`; }
  );
  const unmask = (s: string) => s.replace(/\x00MASK(\d+)\x00/g, (_, i) => maskedBlocks[parseInt(i, 10)]);

  for (const claim of badClaims) {
    // Use multiple search strategies for robust matching
    // Strategy 1: Try with first 60 chars of claim text (longer than before)
    // Strategy 2: Try with key words from the claim (longest distinctive words)
    const claimText = claim.text.replace(/\s+/g, ' ').trim();
    if (claimText.length < 15) continue;

    // Build search patterns from claim text — try multiple fragments
    const fragments: string[] = [];
    // First 60 chars
    fragments.push(claimText.slice(0, 60));
    // Also try a middle fragment and last 40 chars
    if (claimText.length > 60) {
      fragments.push(claimText.slice(Math.floor(claimText.length * 0.3), Math.floor(claimText.length * 0.3) + 50));
      fragments.push(claimText.slice(-50));
    }

    let matched = false;
    for (const fragment of fragments) {
      if (matched) break;
      // Escape regex special chars and allow HTML tags between words
      const escaped = fragment
        .replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
        .replace(/\s+/g, '\\s*');
      if (escaped.length < 15) continue;

      // Also strip HTML tags from the search pattern to match across tags
      const regex = new RegExp(escaped, 'i');
      const match = regex.exec(workingHtml);
      if (match && match.index !== undefined) {
        // Find the sentence boundary around this match
        const before = workingHtml.slice(Math.max(0, match.index - 300), match.index);
        const after = workingHtml.slice(match.index + fragment.length, match.index + fragment.length + 400);

        // Find the end of the sentence — look for </p>, <br>, or .!? followed by space/tag
        const endMatch = after.match(/[.!?]\s|<\/p>|<br\s*\/?>|<\/li>|<\/h[1-6]>/i);
        if (endMatch && endMatch.index !== undefined) {
          const sentenceEnd = match.index + fragment.length + endMatch.index + (endMatch[0].length);

          // Find the start of the sentence
          const startMatch = before.match(/[.!?]\s|<p[^>]*>|<br\s*\/?>|<li[^>]*>|<h[1-6][^>]*>/gi);
          let sentenceStart = match.index;
          if (startMatch) {
            const lastStart = startMatch[startMatch.length - 1];
            const lastStartIdx = before.lastIndexOf(lastStart);
            if (lastStartIdx >= 0) {
              sentenceStart = match.index - (before.length - lastStartIdx - lastStart.length);
            }
          }

          const span = sentenceEnd - sentenceStart;
          const spanText = workingHtml.slice(sentenceStart, sentenceEnd);
          // Safety: never remove spans that cross masked blocks, structural
          // boundaries, data-no-cite editorial elements, or are implausibly
          // long for a single sentence.
          if (mode === 'remove' && span <= 2000 && !/\x00MASK|data-no-cite|<\/?(section|article|header|footer|nav|figure|table)\b/i.test(spanText)) {
            workingHtml = workingHtml.slice(0, sentenceStart) + workingHtml.slice(sentenceEnd);
            removedClaims++;
            details.push(`Removed ${claim.verdict} claim: "${fragment.slice(0, 40)}..."`);
          } else {
            removedClaims++;
            details.push(`Flagged ${claim.verdict} claim: "${fragment.slice(0, 40)}..."`);
          }
          matched = true;
        }
      }
    }
  }

  return { html: unmask(workingHtml), removedClaims, details };
}

// ─── MAIN ENTRY POINT ───────────────────────────────────────────────────────

export async function groundClaims(
  html: string,
  sources: { title: string; abstract?: string | null; fullText?: string | null; fullTextUrl?: string; openAccessPdf?: string; provider?: string }[],
  options?: { mode?: 'remove' | 'flag'; minScore?: number },
): Promise<GroundingResult> {
  const mode = options?.mode ?? 'flag';
  const details: string[] = [];

  // Step 1: Extract sentences from HTML
  const sentences = extractSentencesFromHtml(html);
  console.log(`[CLAIM GROUNDING] Extracted ${sentences.length} sentences from HTML`);

  // Step 2: Decompose into atomic claims
  const claims = decomposeIntoClaims(sentences);
  console.log(`[CLAIM GROUNDING] Decomposed into ${claims.length} atomic claims (${claims.filter(c => c.sourceRef !== null).length} cited, ${claims.filter(c => c.sourceRef === null).length} uncited)`);

  // Step 3: Ground each cited claim against its source
  for (const claim of claims) {
    if (claim.sourceRef === null) continue;
    if (claim.sourceRef < 1 || claim.sourceRef > sources.length) {
      claim.verdict = 'unsupported';
      claim.score = 0;
      continue;
    }

    const source = sources[claim.sourceRef - 1];
    const sourceText = [
      source.title || '',
      source.abstract || '',
      (source.fullText || '').slice(0, 5000), // Use READER V3 extracted full text
    ].join(' ');

    const result = lexicalGrounding(claim, sourceText);
    claim.verdict = result.verdict;
    claim.score = result.score;
    claim.evidenceSnippet = result.evidenceSnippet;
  }

  // Step 3b: RAV + BTProp escalation (V3.1) — for borderline/controversial claims
  const borderlineClaims = claims.filter(c => c.verdict === 'partial' || c.verdict === 'unsupported');
  if (borderlineClaims.length > 0 && borderlineClaims.length <= 5) {
    try {
      const { verifyWithRAV } = await import('./rav-verifier');
      for (const claim of borderlineClaims.slice(0, 3)) {
        if (claim.sourceRef !== null && claim.sourceRef >= 1 && claim.sourceRef <= sources.length) {
          const source = sources[claim.sourceRef - 1];
          const ravResult = await verifyWithRAV(claim.text, [{
            title: source.title,
            abstract: source.abstract || '',
            text: (source as any).fullText || source.abstract || '',
          }]);
          if (ravResult.compositeVerdict === 'supported' && claim.verdict === 'unsupported') {
            claim.verdict = 'partial';
            claim.evidenceSnippet = `RAV: ${ravResult.reasoning}`;
          } else if (ravResult.compositeVerdict === 'contradicted') {
            claim.verdict = 'contradicted';
            claim.evidenceSnippet = `RAV: ${ravResult.reasoning}`;
          }
        }
      }
    } catch (err) {
      console.warn('[CLAIM GROUNDING] RAV escalation failed (non-blocking):', err);
    }
  }

  // Step 4: Aggregate scores
  const supported = claims.filter(c => c.verdict === 'supported').length;
  const partial = claims.filter(c => c.verdict === 'partial').length;
  const unsupported = claims.filter(c => c.verdict === 'unsupported').length;
  const uncited = claims.filter(c => c.verdict === 'uncited').length;
  const contradicted = claims.filter(c => c.verdict === 'contradicted').length;
  const total = claims.length;
  // Groundedness = of claims that cited a source, how many are supported?
  // Uncited claims are narrative prose, not failed grounding.
  const citedTotal = supported + partial + unsupported + contradicted;
  const groundedness = citedTotal > 0 ? (supported + partial * 0.5) / citedTotal : 0;
  // Citation rate = what fraction of factual claims have a citation at all
  const citationRate = total > 0 ? citedTotal / total : 0;
  const strictGroundedness = citedTotal > 0 ? Math.max(0, (supported - contradicted) / citedTotal) : 0;

  console.log(`[CLAIM GROUNDING] Verdicts: ${supported} supported, ${partial} partial, ${unsupported} unsupported, ${uncited} uncited, ${contradicted} contradicted → groundedness ${Math.round(groundedness * 100)}% (citation rate: ${Math.round(citationRate * 100)}%)`);

  // Step 5: Repair HTML
  const repair = repairHtmlWithGrounding(html, claims, mode);
  if (repair.removedClaims > 0) {
    console.log(`[CLAIM GROUNDING] ${mode === 'remove' ? 'Removed' : 'Flagged'} ${repair.removedClaims} unsupported/contradicted claims`);
  }
  details.push(...repair.details.slice(0, 10));

  return {
    claims,
    supported,
    partial,
    unsupported,
    uncited,
    contradicted,
    total,
    groundedness,
    strictGroundedness,
    html: repair.html,
    removedClaims: repair.removedClaims,
    details,
  };
}

// ─── NLI-ENHANCED GROUNDING (async, uses real NLI model) ────────────────────

// SAFE live-search is a frozen-inputs channel (`safe:verify#N`) — grounding
// can run several times per run (citation-grounding + quality-loop), so each
// invocation takes the next slot in call order; replay serves the recorded
// Nth result.
let safeCallIndex = 0;

/**
 * Async version of groundClaims that uses the NLI engine (mDeBERTa-v3)
 * for real entailment classification instead of lexical overlap.
 *
 * This is the upgraded path: when the NLI model is available, each claim
 * is classified as entailment / neutral / contradiction against its cited source.
 * Falls back to lexical grounding if the NLI model is not available.
 *
 * Inspired by VerifAI (2026) and FactReasoner (IBM).
 */
export async function groundClaimsWithNLI(
  html: string,
  sources: { title: string; abstract?: string | null; fullText?: string | null; fullTextUrl?: string; openAccessPdf?: string; provider?: string }[],
  options?: { mode?: 'remove' | 'flag'; minScore?: number; readings?: any[] },
): Promise<GroundingResult> {
  const mode = options?.mode ?? 'flag';
  const details: string[] = [];
  const readings = options?.readings ?? [];

  // Step 1: Extract sentences from HTML
  const sentences = extractSentencesFromHtml(html);
  console.log(`[CLAIM GROUNDING NLI] Extracted ${sentences.length} sentences from HTML`);

  // Step 2: Decompose into atomic claims
  // Try LLM-based decomposition (with decontextualization) first, fall back to deterministic
  let claims = decomposeIntoClaims(sentences);
  const deterministicClaimCount = claims.length;
  let usedLLMDecomposition = false;
  let decompositionCost = 0;
  try {
    const { decomposeIntoAtomicClaims } = await import('./atomic-claims');
    // Build paragraph text from sentences for LLM decomposition
    const paragraphText = sentences.map(s => s.text).join(' ');
    if (paragraphText.length > 50) {
      const atomicResult = await decomposeIntoAtomicClaims(paragraphText, 0);
      // CRITICAL: Only use LLM decomposition if it produces AT LEAST as many claims
      // as the deterministic fallback. The LLM only sees text.slice(0, 4000) which
      // is a tiny fraction of the full document — it often returns 1-2 claims for
      // a 50K-char document, which would nuke the groundedness score to 0%.
      if (atomicResult.usedLLM && atomicResult.claims.length > 0 && atomicResult.claims.length >= deterministicClaimCount) {
        // Map atomic claims back to our AtomicClaim format
        claims = atomicResult.claims.map((ac, idx) => ({
          text: ac.text,
          sentenceIndex: idx,
          sourceRef: ac.sourceRef,
          sourceRefTag: ac.sourceRef !== null ? `[SRC-${ac.sourceRef}]` : null,
          verdict: ac.sourceRef !== null ? 'unsupported' as const : 'uncited' as const,
          evidenceSnippet: null,
          score: 0,
        }));
        usedLLMDecomposition = true;
        decompositionCost = atomicResult.costUsd;
        console.log(`[CLAIM GROUNDING NLI] LLM decomposition: ${claims.length} atomic claims (decontextualized), cost $${decompositionCost.toFixed(4)}`);
      }
    }
  } catch (err) {
    console.warn('[CLAIM GROUNDING NLI] LLM decomposition failed, using deterministic fallback:', String(err).slice(0, 100));
  }
  console.log(`[CLAIM GROUNDING NLI] Decomposed into ${claims.length} atomic claims (${claims.filter(c => c.sourceRef !== null).length} cited, ${claims.filter(c => c.sourceRef === null).length} uncited)${usedLLMDecomposition ? ' [LLM decontextualized]' : ' [deterministic]'}`);

  // Step 3: Ground each cited claim using NLI engine
  const { classifyNLI, nliToGroundingVerdict } = await import('./nli-engine');

  const citedClaims = claims.filter(c => c.sourceRef !== null && c.sourceRef >= 1 && c.sourceRef <= sources.length);

  // Batch classify all cited claims with NLI
  const nliPairs = citedClaims.map(claim => {
    const source = sources[claim.sourceRef! - 1];
    const reading = readings.find((r: any) => r.sourceId === (source as any).id);
    const sourceText = reading
      ? [reading.claims?.join(' '), reading.results?.join(' '), reading.methods?.join(' '), (reading.extractedText || '').slice(0, 2000)].filter(Boolean).join(' ').slice(0, 4000)
      : [source.title || '', source.abstract || '', (source.fullText || '').slice(0, 5000)].join(' ');
    return { claim: claim.text, sourceContent: sourceText, claimRef: claim };
  });

  // Process in batches of 8 for efficiency
  const BATCH_SIZE = 8;
  for (let i = 0; i < nliPairs.length; i += BATCH_SIZE) {
    const batch = nliPairs.slice(i, i + BATCH_SIZE);
    const nliSettled = await Promise.allSettled(
      batch.map(async ({ claimRef, claim, sourceContent }) => {
        const nli = await classifyNLI(claim, sourceContent);
        const verdict = nliToGroundingVerdict(nli);
        return { claimRef, verdict, score: nli.confidence, evidenceSnippet: nli.evidenceSnippet, nliSource: nli.source };
      }),
    );

    const nliResults = nliSettled
      .filter((r): r is PromiseFulfilledResult<any> => r.status === 'fulfilled')
      .map(r => r.value);

    for (const rejected of nliSettled) {
      if (rejected.status === 'rejected') {
        console.warn('[ClaimGrounding] NLI classification failed:', rejected.reason);
      }
    }

    for (const { claimRef, verdict, score, evidenceSnippet, nliSource } of nliResults) {
      claimRef.verdict = verdict;
      claimRef.score = score;
      claimRef.evidenceSnippet = evidenceSnippet ?? null;
    }
  }

  // Handle invalid source refs
  for (const claim of claims) {
    if (claim.sourceRef !== null && (claim.sourceRef < 1 || claim.sourceRef > sources.length)) {
      claim.verdict = 'unsupported';
      claim.score = 0;
    }
  }

  // Step 3c: SAFE escalation (DeepMind SAFE, NeurIPS 2024) — claims that
  // stored-source grounding could not confirm are verified against LIVE web
  // search. A claim unsupported by its thin abstract may be provable against
  // fresh evidence; a claim contradicted everywhere is genuinely dangerous.
  // Bounded: 12 claims max, ~$0.001 + metered search calls.
  // Check-worthiness triage (Loki-style): rank candidates by factual value —
  // quantitative/causal/named-entity claims are worth a live call; vague prose
  // is not. First-12-in-document order wasted budget on filler.
  const checkWorthiness = (text: string): number => {
    let score = 0;
    if (/\d+\s*%|\$\s*\d|\d{4,}|million|billion|trillion/i.test(text)) score += 3; // quantitative
    if (/\b(caused?|driv(?:es|en|ing)|led to|result(?:s|ed)? in|increase[ds]?|reduce[ds]?|decline[ds]?)\b/i.test(text)) score += 2; // causal
    if (/\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+\b/.test(text)) score += 1; // named entities
    if (/\b(will|would|could)\b.*\b(by|in)\s+(?:19|20)\d{2}\b/i.test(text)) score += 1; // forecast
    return score;
  };
  const safeCandidates = claims.filter(c =>
    c.verdict === 'unsupported' ||
    c.verdict === 'contradicted' ||
    (c.verdict === 'uncited' && checkWorthiness(c.text) >= 3)
  )
    .map(c => ({ c, w: checkWorthiness(c.text) + (c.verdict === 'contradicted' ? 4 : 0) }))
    .sort((a, b) => b.w - a.w)
    .slice(0, 12)
    .map(x => x.c);

  if (safeCandidates.length > 0) {
    try {
      const { verifyClaimsWithLiveSearch } = await import('./safe-verifier');
      const { captureInput } = await import('./frozen-inputs');
      const safeReport = await captureInput(`safe:verify#${safeCallIndex++}`, () =>
        verifyClaimsWithLiveSearch(
          safeCandidates.map(c => c.text),
          { maxClaims: 12, timeoutMs: 100_000 },
        ));
      let rescued = 0;
      for (let i = 0; i < safeCandidates.length && i < safeReport.results.length; i++) {
        const claim = safeCandidates[i];
        const safe = safeReport.results[i];
        if (!safe) continue;
        if (safe.verdict === 'supported' && claim.verdict !== 'contradicted') {
          // Live evidence confirms the claim — upgrade conservatively to
          // 'supported' only on high-confidence entailment, else 'partial'.
          claim.verdict = safe.confidence >= 0.75 ? 'supported' : 'partial';
          claim.evidenceSnippet = `SAFE: ${safe.evidenceUrls[0] || safe.evidenceSnippet || 'live search'}`;
          claim.score = Math.max(claim.score, safe.confidence);
          rescued++;
        } else if (safe.verdict === 'contradicted') {
          // Fresh evidence contradicts the claim — this overrides everything.
          claim.verdict = 'contradicted';
          claim.evidenceSnippet = `SAFE contradicted: ${safe.evidenceUrls[0] || ''}`;
        }
        // 'unverifiable' leaves the original verdict untouched.
      }
      if (rescued > 0 || safeReport.contradicted > 0) {
        console.log(`[CLAIM GROUNDING NLI] SAFE: ${rescued} claims rescued by live evidence, ${safeReport.contradicted} contradicted by live evidence (precision ${Math.round(safeReport.precision * 100)}%)`);
      }
      details.push(`SAFE: ${safeReport.supported} live-supported, ${safeReport.contradicted} live-contradicted, ${safeReport.unverifiable} unverifiable`);
    } catch (err) {
      console.warn('[CLAIM GROUNDING NLI] SAFE escalation failed (non-blocking):', String(err).slice(0, 120));
    }
  }

  // Step 4: Aggregate scores (same as lexical version)
  const supported = claims.filter(c => c.verdict === 'supported').length;
  const partial = claims.filter(c => c.verdict === 'partial').length;
  const unsupported = claims.filter(c => c.verdict === 'unsupported').length;
  const uncited = claims.filter(c => c.verdict === 'uncited').length;
  const contradicted = claims.filter(c => c.verdict === 'contradicted').length;
  const total = claims.length;
  const citedTotal = supported + partial + unsupported + contradicted;
  const groundedness = citedTotal > 0 ? (supported + partial * 0.5) / citedTotal : 0;
  const citationRate = total > 0 ? citedTotal / total : 0;
  const strictGroundedness = citedTotal > 0 ? Math.max(0, (supported - contradicted) / citedTotal) : 0;

  console.log(`[CLAIM GROUNDING NLI] Verdicts: ${supported} supported, ${partial} partial, ${unsupported} unsupported, ${uncited} uncited, ${contradicted} contradicted → groundedness ${Math.round(groundedness * 100)}% (citation rate: ${Math.round(citationRate * 100)}%)`);

  // Step 5: Repair HTML
  const repair = repairHtmlWithGrounding(html, claims, mode);
  if (repair.removedClaims > 0) {
    console.log(`[CLAIM GROUNDING NLI] ${mode === 'remove' ? 'Removed' : 'Flagged'} ${repair.removedClaims} unsupported/contradicted claims`);
  }
  details.push(...repair.details.slice(0, 10));

  return {
    claims,
    supported,
    partial,
    unsupported,
    uncited,
    contradicted,
    total,
    groundedness,
    strictGroundedness,
    html: repair.html,
    removedClaims: repair.removedClaims,
    details,
  };
}

// ============================================================================
// S18: Agent-Enhanced Graph RAG — Graph-based claim verification
// arXiv 2609.00761 (Sep 2026)
// ============================================================================
//
// Builds a lightweight knowledge graph from source texts and verifies claims
// against it using graph traversal. This catches hallucinations that lexical
// matching misses: a claim may use different words but assert a relationship
// that doesn't exist in the source graph.
//
// The graph is built deterministically (no LLM):
// 1. Extract entity nodes from each source (capitalized phrases, numbers, dates)
// 2. Extract relationship edges (co-occurrence within a sentence = edge)
// 3. For each claim, check if its entities and relationships exist in the graph
// 4. Claims with entities not in the graph or relationships not in the graph
//    get a "graph_unsupported" flag
//
// This is complementary to lexical grounding: lexical catches copy-paste
// hallucinations, graph catches semantic hallucinations.

export interface GraphNode {
  id: string;
  text: string;
  sourceIdx: number;
  type: 'entity' | 'number' | 'date';
}

export interface GraphEdge {
  from: string;
  to: string;
  sourceIdx: number;
  coOccurrenceCount: number;
}

export interface SourceGraph {
  nodes: Map<string, GraphNode>;
  edges: Map<string, GraphEdge>;
  nodeCount: number;
  edgeCount: number;
}

function extractEntities(text: string, sourceIdx: number): GraphNode[] {
  const nodes: GraphNode[] = [];
  const seen = new Set<string>();

  const entityMatches = text.match(/\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,3}\b/g) || [];
  for (const match of entityMatches) {
    const key = `${match.toLowerCase()}_${sourceIdx}`;
    if (!seen.has(key) && match.length > 2) {
      seen.add(key);
      nodes.push({ id: key, text: match, sourceIdx, type: 'entity' });
    }
  }

  const numberMatches = text.match(/\b\d+(?:\.\d+)?%?\b/g) || [];
  for (const match of numberMatches) {
    const key = `num_${match}_${sourceIdx}`;
    if (!seen.has(key)) {
      seen.add(key);
      nodes.push({ id: key, text: match, sourceIdx, type: 'number' });
    }
  }

  const dateMatches = text.match(/\b(?:19|20)\d{2}\b/g) || [];
  for (const match of dateMatches) {
    const key = `date_${match}_${sourceIdx}`;
    if (!seen.has(key)) {
      seen.add(key);
      nodes.push({ id: key, text: match, sourceIdx, type: 'date' });
    }
  }

  return nodes;
}

function extractEdges(text: string, nodes: GraphNode[], sourceIdx: number): GraphEdge[] {
  const edges: GraphEdge[] = [];
  const sentences = text.split(/[.!?]+/);

  for (const sentence of sentences) {
    const sentenceNodes = nodes.filter(n =>
      n.sourceIdx === sourceIdx && sentence.includes(n.text)
    );
    for (let i = 0; i < sentenceNodes.length; i++) {
      for (let j = i + 1; j < sentenceNodes.length; j++) {
        edges.push({
          from: sentenceNodes[i].id,
          to: sentenceNodes[j].id,
          sourceIdx,
          coOccurrenceCount: 1,
        });
      }
    }
  }

  return edges;
}

export function buildSourceGraph(sources: string[]): SourceGraph {
  const nodes = new Map<string, GraphNode>();
  const edges = new Map<string, GraphEdge>();

  sources.forEach((text, sourceIdx) => {
    const sourceNodes = extractEntities(text, sourceIdx);
    for (const node of sourceNodes) {
      nodes.set(node.id, node);
    }

    const sourceEdges = extractEdges(text, sourceNodes, sourceIdx);
    for (const edge of sourceEdges) {
      const key = `${edge.from}|${edge.to}`;
      const existing = edges.get(key);
      if (existing) {
        existing.coOccurrenceCount++;
      } else {
        edges.set(key, edge);
      }
    }
  });

  return {
    nodes,
    edges,
    nodeCount: nodes.size,
    edgeCount: edges.size,
  };
}

export interface GraphGroundingResult {
  claimIdx: number;
  claimText: string;
  sourceIdx: number;
  entitiesInGraph: number;
  entitiesTotal: number;
  relationshipsInGraph: number;
  relationshipsTotal: number;
  graphScore: number;
  verdict: ClaimVerdict;
}

export function verifyClaimAgainstGraph(
  claimText: string,
  sourceIdx: number,
  graph: SourceGraph,
): GraphGroundingResult {
  const claimEntities = extractEntities(claimText, sourceIdx);
  const claimEdges = extractEdges(claimText, claimEntities, sourceIdx);

  let entitiesInGraph = 0;
  for (const entity of claimEntities) {
    if (graph.nodes.has(entity.id)) entitiesInGraph++;
  }

  let relationshipsInGraph = 0;
  for (const edge of claimEdges) {
    const key = `${edge.from}|${edge.to}`;
    const reverseKey = `${edge.to}|${edge.from}`;
    if (graph.edges.has(key) || graph.edges.has(reverseKey)) {
      relationshipsInGraph++;
    }
  }

  const entityScore = claimEntities.length > 0 ? entitiesInGraph / claimEntities.length : 0.5;
  const relationshipScore = claimEdges.length > 0 ? relationshipsInGraph / claimEdges.length : 0.5;
  const graphScore = entityScore * 0.6 + relationshipScore * 0.4;

  let verdict: ClaimVerdict;
  if (graphScore >= 0.7) verdict = 'supported';
  else if (graphScore >= 0.4) verdict = 'partial';
  else verdict = 'unsupported';

  return {
    claimIdx: -1,
    claimText,
    sourceIdx,
    entitiesInGraph,
    entitiesTotal: claimEntities.length,
    relationshipsInGraph,
    relationshipsTotal: claimEdges.length,
    graphScore,
    verdict,
  };
}

export function graphGroundClaims(
  claims: AtomicClaim[],
  sources: string[],
): GraphGroundingResult[] {
  if (sources.length === 0 || claims.length === 0) return [];

  const graph = buildSourceGraph(sources);
  const results: GraphGroundingResult[] = [];

  for (let i = 0; i < claims.length; i++) {
    const claim = claims[i];
    if (claim.sourceRef === null || claim.sourceRef < 1 || claim.sourceRef > sources.length) {
      continue;
    }
    const sourceIdx = claim.sourceRef - 1;
    const result = verifyClaimAgainstGraph(claim.text, sourceIdx, graph);
    result.claimIdx = i;
    results.push(result);
  }

  return results;
}
